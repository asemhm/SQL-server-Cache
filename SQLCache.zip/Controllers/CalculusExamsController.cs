﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using SQLCache.DAL;
using SQLCache.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.Json;

namespace SQLCache.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CalculusExamsController : Controller
    {
        private readonly IDataCache _iDataCache;
        private readonly CalculusExamsContext _context;
        private readonly IDistributedCache _distributedCache;

        public CalculusExamsController(IDataCache iDataCache, CalculusExamsContext context, IDistributedCache distributedCache)
        {
            _iDataCache = iDataCache;
            _context = context;
            _distributedCache = distributedCache;

        }
        [HttpGet]
        [Route("GetScores")]
        public List<CalculusExamsScores> Index(int month = 1,int year = 2022 ,long StudentId = 1 , double ScoresValue = 24)
        {
            string MethodName = string.Format("{0}.{1}", MethodBase.GetCurrentMethod().DeclaringType.FullName, MethodBase.GetCurrentMethod().Name);

            byte[] objectFromCache = _iDataCache.Get(MethodName, month, year, StudentId, ScoresValue);
            if (objectFromCache != null)
            {
              
                var jsonToDeserialize = System.Text.Encoding.UTF8.GetString(objectFromCache);
                var cachedResult = JsonSerializer.Deserialize<List<CalculusExamsScores>>(jsonToDeserialize);
                if (cachedResult != null)
                {
                 
                    return cachedResult;
                }
            }

            var result =  _context.CalculusExamsScores .Where(
                                                             c=>c.CalculusExamsScoresMonth == month 
                                                             && c.CalculusExamsScoresYear == year
                                                               &&  c.CalculusExamsScoresStudentId == StudentId
                                                               && c.CalculusExamsScoresValue == ScoresValue).Take(8000).ToList();

            byte[] objectToCache = JsonSerializer.SerializeToUtf8Bytes(result);

            _iDataCache.Set(MethodName, objectToCache, month, year, StudentId, ScoresValue);
            return result;
        }
    }
}
