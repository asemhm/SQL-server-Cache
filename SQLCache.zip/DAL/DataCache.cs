﻿using Microsoft.Extensions.Caching.Distributed;
using SQLCache.Models;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace SQLCache.DAL
{
    public class DataCache : IDataCache
    {
        private readonly IDistributedCache _distributedCache;

        public DataCache(IDistributedCache distributedCache)
        {
            _distributedCache = distributedCache;
        }

        public byte[] Get(string MethodName , params  object[] _params)
        {
            var CurrentcacheName = MethodName;
            foreach (var item in _params)
            {
                CurrentcacheName= CurrentcacheName+"_"+item.ToString();
            }
         return  _distributedCache.Get(CurrentcacheName);
     
        }
     

        public void Set(string MethodName, byte[] objectToCache, params object[] _params)
        {
            var CurrentcacheName = MethodName;
            foreach (var item in _params)
            {
                CurrentcacheName = CurrentcacheName + "_" + item.ToString();
            }
            var cacheEntryOptions = new DistributedCacheEntryOptions()
                .SetSlidingExpiration(TimeSpan.FromSeconds(3600))
                .SetAbsoluteExpiration(TimeSpan.FromSeconds(3600));

            // Cache it
            _distributedCache.Set(CurrentcacheName, objectToCache, cacheEntryOptions);
        }
    }
}
