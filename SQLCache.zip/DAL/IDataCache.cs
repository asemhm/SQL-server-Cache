﻿using Microsoft.Extensions.Caching.Distributed;
using System.Threading.Tasks;
using System.Threading;

namespace SQLCache.DAL
{
    public interface IDataCache
    {
        byte[] Get(string MethodName,params  object[] _params);
       
        void Set(string MethodName, byte[] value,params object[] _params);
      
    }
}

