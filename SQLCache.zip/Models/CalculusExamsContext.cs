﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SQLCache.Models
{
    public partial class CalculusExamsContext : DbContext
    {
        public CalculusExamsContext()
        {
        }

        public CalculusExamsContext(DbContextOptions<CalculusExamsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CalculusExamsScores> CalculusExamsScores { get; set; }
        public virtual DbSet<Sqlcache> Sqlcache { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=CalculusExams;Data Source=.;MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CalculusExamsScores>(entity =>
            {
                entity.Property(e => e.CalculusExamsScoresId).HasColumnName("CalculusExamsScoresID");

                entity.Property(e => e.CalculusExamsScoresStudentId).HasColumnName("CalculusExamsScoresStudentID");
            });

            modelBuilder.Entity<Sqlcache>(entity =>
            {
                entity.ToTable("SQLCache");

                entity.Property(e => e.Id).HasMaxLength(449);

                entity.Property(e => e.Value).IsRequired();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
