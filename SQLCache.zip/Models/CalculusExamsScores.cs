﻿using System;
using System.Collections.Generic;

namespace SQLCache.Models
{
    public partial class CalculusExamsScores
    {
        public long CalculusExamsScoresId { get; set; }
        public int  CalculusExamsScoresMonth { get; set; }
        public int  CalculusExamsScoresYear { get; set; }
        public long  CalculusExamsScoresStudentId { get; set; }
        public double  CalculusExamsScoresValue { get; set; }
    }
}
